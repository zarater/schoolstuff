#include "BST.h"


int main()
{
	bst bstfunc;
	node to_add, checkn;

		questions(to_add, checkn, bstfunc);


	return 1;
}
